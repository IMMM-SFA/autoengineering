"""Native current design for up to 24 supplied passive-circuit load cases.

At the common absolute voltage threshold, each case has one required current.
The largest requirement controls all voltage constraints because the passive
circuit's current-voltage relation is strictly increasing. Source power also
increases with positive current in every case, so the controlling case and mean
power share the same current minimizer. SLSQP still uses the intact coupled
OpenMDAO model and its total derivatives. Every supplied case is checked freshly.

This development recipe opens no private source and admits no final scenarios.
The older combined-corner recipe is unchanged.
"""

from __future__ import annotations

from itertools import islice
import math
from pathlib import Path

import numpy as np

from examples.interoperability.circuit.model import factory
from examples.utility.engineering_load import context, diagnostics
from examples.utility.engineering_load_native import direct, dominant_scenario


def controlling_scenario(scenarios, minimum_voltage):
    """Return the threshold-controlling supplied case without running a model.

    Kirchhoff and Ohm laws give I = v/R1 + (1 + R2/R1) Is expm1(v/Vt),
    where v = minimum_voltage - ground and the fixed diode has Is=1e-15 A,
    Vt=0.025875 V. An unrepresentable threshold refuses before model construction.
    """
    cases = tuple(islice(scenarios, 25))
    if not cases or len(cases) > 24 or len({s.scenario_id for s in cases}) != len(cases):
        raise ValueError("robust native load recipe requires 1 to 24 unique supplied cases")
    if type(minimum_voltage) not in (int, float) or not math.isfinite(minimum_voltage):
        raise ValueError("robust native load voltage requirement must be finite")
    requirements = []
    for case in cases:
        dominant_scenario((case,))  # Reuse strict finite, positive-resistance validation.
        ground, r1, r2 = (
            case.forcing[n] for n in ("ground_voltage", "resistor1_ohm", "resistor2_ohm")
        )
        v = minimum_voltage - ground
        try:
            current = v / r1 + (1 + r2 / r1) * 1e-15 * math.expm1(v / 0.025875)
        except OverflowError as error:
            raise ValueError("robust native threshold current is not representable") from error
        if not math.isfinite(current):
            raise ValueError("robust native threshold current is not representable")
        requirements.append(current)
    return cases[max(range(len(cases)), key=requirements.__getitem__)]


def native_design(
    scenarios, minimum_voltage, scratch, *, max_iterations=20, max_solves=40, source_root=None
):
    """Optimize the threshold-controlling case and verify every supplied load."""
    scenarios = tuple(islice(scenarios, 25))
    worst = controlling_scenario(scenarios, minimum_voltage)
    if type(minimum_voltage) not in (int, float) or not np.isfinite(minimum_voltage):
        raise ValueError("native load voltage requirement must be finite")
    if (
        type(max_iterations) is not int
        or type(max_solves) is not int
        or max_iterations < 1
        or max_solves <= len(scenarios)
    ):
        raise ValueError("native load cap cannot cover optimization and fresh scenario checks")
    import openmdao.api as om

    problem = factory(context(0.05, scratch, source_root=source_root))
    circuit = problem.model.circuit
    original_configure = circuit.configure

    def configure():
        original_configure()
        circuit.R1.options["R"] = worst.forcing["resistor1_ohm"]
        circuit.R2.options["R"] = worst.forcing["resistor2_ohm"]

    circuit.configure = configure
    problem.model.add_subsystem(
        "power",
        om.ExecComp(
            "P=I*(V-G)", I={"units": "A"}, V={"units": "V"}, G={"units": "V"}, P={"units": "W"}
        ),
    )
    problem.model.connect("source.I", "power.I")
    problem.model.connect("ground.V", "power.G")
    problem.model.connect("circuit.n1.V", "power.V")
    problem.model.add_design_var("source.I", lower=0.01, upper=0.1)
    problem.model.add_objective("power.P")
    problem.model.add_constraint("circuit.n2.V", lower=minimum_voltage)
    problem.driver = om.ScipyOptimizeDriver(
        optimizer="SLSQP", tol=1e-10, disp=False, maxiter=max_iterations
    )
    records = []
    original = problem.model.run_solve_nonlinear

    def counted(*args, **kwargs):
        if len(records) >= max_solves - len(scenarios):
            raise RuntimeError("native load solve budget exhausted")
        records.append({"status": "started"})
        try:
            result = original(*args, **kwargs)
            records[-1] = {"status": "completed", "work": diagnostics(problem).to_dict()}
            return result
        except BaseException:
            records[-1]["status"] = "failed"
            raise

    problem.model.run_solve_nonlinear = counted
    try:
        problem.setup()
        problem.final_setup()
        if (circuit.D1.options["Is"], circuit.D1.options["Vt"]) != (1e-15, 0.025875):
            raise ValueError("robust native threshold reduction differs from the supplied diode")
        problem.set_val("ground.V", worst.forcing["ground_voltage"], units="V")
        driver = problem.run_driver()
        current = float(problem.get_val("source.I").item())
        final_work = diagnostics(problem).to_dict()
        fresh = [
            direct(current, scenario, scratch, source_root=source_root) for scenario in scenarios
        ]
        powers = [
            current * (row["outputs"]["node1_voltage"] - case.forcing["ground_voltage"])
            for case, row in zip(scenarios, fresh, strict=True)
        ]
        feasible = all(
            all(math.isfinite(value) for value in row["outputs"].values())
            and row["work"]["converged"]
            and row["work"]["residual_norm"] <= 1e-10
            and row["work"]["residual_tolerance"] == 1e-10
            and row["work"]["solver_iterations"] <= 100
            and row["outputs"]["node2_voltage"] >= minimum_voltage
            and math.isfinite(power)
            and power >= 0
            for row, power in zip(fresh, powers, strict=True)
        )
        return {
            "source_current_A": current,
            "driver_success": bool(driver.success),
            "controlling_scenario": worst.scenario_id,
            "native_solves": records,
            "scenario_solves": fresh,
            "driver_final_work": final_work,
            "physical_solves": len(records) + len(fresh),
            "feasible": feasible,
            "mean_source_power_W": math.fsum(powers) / len(powers),
        }
    finally:
        problem.cleanup()


def execute(job):
    """Return the existing native-driver record; final acceptance stays authoritative."""
    from autoengineering.utility.engineering_native import (
        NativeDriverResult,
        NativeSolveRecord,
        NativeSolverState,
    )
    from examples.utility.engineering import rules as circuit_rules

    spec = job.specification
    rules = spec.execution.study.rules
    check = next(c for c in rules.checks if c.name == "node_voltage" and c.required)
    minimum = check.options["minimum_V"]
    parameters = spec.execution.study.run.search_space.parameters
    if (
        len(parameters) != 1
        or parameters[0].name != "source_current"
        or (
            getattr(parameters[0], "lower", None),
            getattr(parameters[0], "upper", None),
            getattr(parameters[0], "scale", None),
        )
        != (0.01, 0.1, "linear")
        or rules != circuit_rules(minimum, rules.minimum_gain)
    ):
        raise ValueError("native load recipe differs from its bounds or acceptance")
    result = native_design(
        spec.execution.scenarios,
        minimum,
        Path(job.scratch_path),
        max_iterations=spec.max_iterations,
        max_solves=spec.max_model_solves,
        source_root=Path(job.source_root),
    )

    def state(work):
        return NativeSolverState(
            work["converged"],
            work["residual_norm"],
            work["residual_tolerance"],
            "A",
            work["solver_iterations"],
            work["component_calls"],
            work["derivative_calls"],
        )

    calls = [
        NativeSolveRecord("driver", None, "shared_problem_snapshot", state(r["work"]))
        for r in result["native_solves"]
    ]
    calls += [
        NativeSolveRecord("scenario", scenario.scenario_id, "independent_problem", state(r["work"]))
        for scenario, r in zip(spec.execution.scenarios, result["scenario_solves"])
    ]
    if len(calls) != result["physical_solves"]:
        raise ValueError("native load model-call accounting differs")
    return NativeDriverResult(
        "utility-native-result-v2",
        job.digest,
        {"source_current": result["source_current_A"]},
        result["driver_success"],
        tuple(calls),
        state(result["driver_final_work"]),
    )
