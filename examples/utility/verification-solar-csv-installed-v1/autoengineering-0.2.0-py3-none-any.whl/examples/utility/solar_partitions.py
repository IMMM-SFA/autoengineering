"""Separate normalized solar development and reserved inputs in trusted preparation.

No model, network or raw source reader. Claims precede row iteration and the
private manifest commits before the public manifest. This is not an OS privacy
boundary, source verification, exposure attestation or task/scorer admission.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
import hashlib
from pathlib import Path
from typing import Literal

from autoengineering.campaign.serialization import Record, canonical_json, digest
from autoengineering.campaign.store import checked_directory, durable_write
from autoengineering.utility.contracts import sha256
from examples.utility.solar_intervals import AlignedInterval, SolarAlignmentPlan, instant

MAX_ARTIFACT_BYTES = 64 * 1024**2


@dataclass(frozen=True)
class SolarWindow(Record):
    role: Literal["warmup", "fitting", "selection", "confirmation"]
    start: str
    end: str

    def _validate(self):
        if instant(self.start) >= instant(self.end):
            raise ValueError("solar window must have positive support")


@dataclass(frozen=True)
class SolarPartitionPlan(Record):
    schema: Literal["utility-solar-partitions-v1"]
    alignment: SolarAlignmentPlan
    windows: tuple[SolarWindow, ...]
    hardware_review_digest: str
    segment_warmup_intervals: int
    state_policy: Literal["forcing_only_continuity_reset_on_driver_gaps"]

    def _validate(self):
        sha256(self.hardware_review_digest)
        if tuple(w.role for w in self.windows) != (
            "warmup",
            "fitting",
            "selection",
            "confirmation",
        ):
            raise ValueError("solar partition needs four ordered role windows")
        if not 0 <= self.segment_warmup_intervals <= 10000:
            raise ValueError("solar segment warmup must be explicitly bounded")
        start = instant(self.alignment.start)
        if instant(self.windows[0].start) != start or instant(self.windows[-1].end) != instant(
            self.alignment.end
        ):
            raise ValueError("solar windows must cover the full alignment range")
        for window in self.windows:
            if any(
                (instant(v) - start).total_seconds() % self.alignment.step_seconds
                for v in (window.start, window.end)
            ):
                raise ValueError("solar window must match target interval boundaries")
        if any(instant(a.end) != instant(b.start) for a, b in zip(self.windows, self.windows[1:])):
            raise ValueError("solar windows must be contiguous without overlap")


def prepare(plan, rows, public_root, private_root):
    """Publish source-bound normalized artifacts with labels kept in their roles.

    Driver continuity ignores missing AC labels. Driver gaps reset the segment
    and require the declared number of unscored warmup intervals. A fitting/role
    boundary alone does not reset driver state. Actual model initialization and
    source semantics still require qualified task bindings.
    """
    try:
        if not isinstance(plan, SolarPartitionPlan):
            raise ValueError("invalid solar partition plan")
        public, private = checked_directory(public_root), checked_directory(private_root)
        if (
            public.is_relative_to(private)
            or private.is_relative_to(public)
            or any(public.iterdir())
            or any(private.iterdir())
        ):
            raise ValueError("solar output scopes must be empty and separate")
        sources = {
            "partition": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "alignment": hashlib.sha256(
                Path(__file__).with_name("solar_intervals.py").read_bytes()
            ).hexdigest(),
        }
        binding = digest(
            {
                "plan": plan.digest,
                "sources": sources,
                "public": str(public),
                "private": str(private),
            }
        )
        for path, role in sorted(
            ((public, "public"), (private, "private")), key=lambda pair: str(pair[0])
        ):
            durable_write(
                path / "preparation-claim.json",
                canonical_json(
                    {
                        "schema": "utility-solar-preparation-claim-v1",
                        "binding": binding,
                        "plan_digest": plan.digest,
                        "preparer_sources": sources,
                        "scope": role,
                    }
                ).encode(),
            )
        start, stop = instant(plan.alignment.start), instant(plan.alignment.end)
        step = plan.alignment.step_seconds
        count = int((stop - start).total_seconds()) // step
        alignment_identity = plan.alignment.digest
        saved, roles, segments, score = [], [], [], []
        window_index = 0
        segment = -1
        run_length = 0
        for row in rows:
            if len(saved) >= count or not isinstance(row, AlignedInterval):
                raise ValueError("solar aligned row envelope")
            if (
                row.alignment_digest != alignment_identity
                or row.alignment_implementation_digest != sources["alignment"]
            ):
                raise ValueError("solar row belongs to another alignment policy")
            expected = start + timedelta(seconds=step * len(saved))
            if (
                instant(row.start) != expected
                or instant(row.end) != expected + timedelta(seconds=step)
                or row.duration_seconds != step
            ):
                raise ValueError("solar row support differs from frozen alignment")
            while expected >= instant(plan.windows[window_index].end):
                window_index += 1
            role = plan.windows[window_index].role
            if row.drivers_usable:
                if run_length == 0:
                    segment += 1
                run_length += 1
                segment_id = segment
            else:
                run_length = 0
                segment_id = None
            saved.append(row)
            roles.append(role)
            segments.append(segment_id)
            score.append(
                row.usable and role != "warmup" and run_length > plan.segment_warmup_intervals
            )
        if len(saved) != count:
            raise ValueError("solar row count differs")
        if any(
            not any(keep and r == role for keep, r in zip(score, roles))
            for role in ("fitting", "selection", "confirmation")
        ):
            raise ValueError("solar role has no usable scored support")
        dev_count = next(i for i, role in enumerate(roles) if role == "confirmation")

        def forcing(size):
            subset = saved[:size]
            return {
                "start": [r.start for r in subset],
                "end": [r.end for r in subset],
                "duration_seconds": [r.duration_seconds for r in subset],
                "poa_w_m2": [r.poa_w_m2 for r in subset],
                "temperature_c": [r.temperature_c for r in subset],
                "wind_m_s": [r.wind_m_s for r in subset],
                "drivers_usable": [r.drivers_usable for r in subset],
                "segment_id": segments[:size],
            }

        def labels(role, size):
            mask = [keep and r == role for keep, r in zip(score[:size], roles[:size])]
            return {
                "ac_kw": [r.ac_kw if keep else None for r, keep in zip(saved[:size], mask)],
                "energy_kwh": [
                    r.ac_energy_kwh if keep else None for r, keep in zip(saved[:size], mask)
                ],
                "score_mask": mask,
            }

        public_docs = {
            "forcing.json": forcing(dev_count),
            "fitting.json": labels("fitting", dev_count),
            "selection.json": labels("selection", dev_count),
        }
        private_docs = {
            "forcing.json": forcing(count),
            "labels.json": labels("confirmation", count),
        }
        encoded_public = {
            name: canonical_json(value).encode() for name, value in public_docs.items()
        }
        encoded_private = {
            name: canonical_json(value).encode() for name, value in private_docs.items()
        }
        if any(
            len(raw) > MAX_ARTIFACT_BYTES
            for raw in (*encoded_public.values(), *encoded_private.values())
        ):
            raise ValueError("solar artifact byte bound")
        private_manifest = {
            "schema": "utility-solar-private-v1",
            "plan_digest": plan.digest,
            "preparer_sources": sources,
            "files": {name: digest(value) for name, value in private_docs.items()},
        }
        manifest = {
            "schema": "utility-solar-public-v1",
            "plan": plan.to_dict(),
            "plan_digest": plan.digest,
            "preparer_sources": sources,
            "normalized_rows_digest": digest([r.to_dict() for r in saved]),
            "files": {name: digest(value) for name, value in public_docs.items()},
            "private_bundle_digest": digest(private_manifest),
            "development_roles": roles[:dev_count],
            "confirmation_rows": count - dev_count,
            "state_policy": plan.state_policy,
            "source_bytes_verified": False,
            "exposure_attested": False,
            "scientific_adapter_admitted": False,
            "private_boundary_qualified": False,
        }
        for name, raw in encoded_private.items():
            durable_write(private / name, raw)
        durable_write(private / "manifest.json", canonical_json(private_manifest).encode())
        for name, raw in encoded_public.items():
            durable_write(public / name, raw)
        durable_write(public / "manifest.json", canonical_json(manifest).encode())
        return manifest
    except Exception:
        pass
    # Raise outside the handler so the returned exception cannot retain a
    # private input exception through __context__ or __cause__.
    raise ValueError("solar partition preparation failed") from None
