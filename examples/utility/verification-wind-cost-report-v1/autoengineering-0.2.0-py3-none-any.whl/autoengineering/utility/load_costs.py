"""Core metadata reader for caller-pinned coupled-load callback work receipts.

The callback's work record is trusted application evidence, not an OS proof.
Missing records and interrupted native attempts retain unknown totals. Permission,
case attempts, completed evaluations and actual starts are separate quantities.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Literal

from autoengineering.campaign.artifacts import confined_file, read_bytes
from autoengineering.campaign.records import ArtifactRef
from autoengineering.campaign.serialization import Record, digest, unique_json
from autoengineering.campaign.store import StoreError
from autoengineering.utility.confirmation import read_selected_state
from autoengineering.utility.contracts import identifier, sha256
from autoengineering.utility.costs import CostRecord
from autoengineering.utility.outcomes import OutcomeSpec
from autoengineering.utility.scoring import ConfirmationGrant, _read, read_receipt, validate_grant
from .wind_costs import WindCostInput, join_wind_costs


@dataclass(frozen=True)
class LoadScorePolicy(Record):
    schema: Literal["utility-coupled-load-score-v1"]
    expected_model_digest: str
    scorer_source_digest: str
    minimum_node2_voltage_V: float
    outcome: Literal["mean_source_power"] = "mean_source_power"
    units: Literal["W"] = "W"
    maximum_cases: Literal[24] = 24
    residual_tolerance_A: Literal[1e-10] = 1e-10
    fixed_solver_maximum_iterations: Literal[100] = 100

    def _validate(self):
        sha256(self.expected_model_digest)
        sha256(self.scorer_source_digest)


@dataclass(frozen=True)
class SourceBinding(Record):
    schema: Literal["utility-engineering-source-binding-v1"]
    task_id: str
    suite_digest: str
    partition_policy_digest: str
    public_manifest_digest: str
    private_record_digest: str
    seed_commitment: str
    source_claim_digest: str
    generation_digest: str
    preparer_source_digest: str
    binding_source_digest: str
    task_admitted: Literal[False] = False
    private_boundary_qualified: Literal[False] = False

    def _validate(self):
        identifier(self.task_id)
        for name in (
            "suite_digest",
            "partition_policy_digest",
            "public_manifest_digest",
            "private_record_digest",
            "seed_commitment",
            "source_claim_digest",
            "generation_digest",
            "preparer_source_digest",
            "binding_source_digest",
        ):
            sha256(getattr(self, name))


def read_binding(store, artifact):
    """Verify the original metadata binding without importing source generators."""
    fixed = SourceBinding.from_json(read_bytes(store.root, artifact, max_bytes=65536).decode())
    if (
        artifact.path != f"engineering-source-bindings/{fixed.task_id}.json"
        or artifact.media_type != "application/json"
    ):
        raise ValueError("load source binding role differs")
    task = next(t for t in store.spec.tasks if t.task_id == fixed.task_id)
    if (
        task.family != "engineering"
        or store.spec.digest != fixed.suite_digest
        or task.partition_digest != fixed.partition_policy_digest
    ):
        raise ValueError("load source binding differs from suite task")
    path = confined_file(store.root, f"engineering-scenario-preparations/{fixed.task_id}.json")
    if path.stat().st_size > 65536:
        raise ValueError("load source claim exceeds metadata bound")
    if digest(unique_json(path.read_text())) != fixed.source_claim_digest:
        raise ValueError("load source binding differs from original generation claim")
    return fixed


def scorer_identity(fixed, scorer_code_digest):
    sha256(scorer_code_digest)
    return digest(
        {
            "schema": "utility-engineering-bound-scorer-v1",
            "scorer_code_digest": scorer_code_digest,
            "source_binding_digest": fixed.digest,
        }
    )


WORK_DIRECTORY = "engineering-load-work"
COUNTER_SCOPE = "component _linearize invocations, including Newton linearization; not FLOPs"


@dataclass(frozen=True)
class CounterWork(Record):
    solver_iterations: int
    component_calls: int
    derivative_calls: int

    def _validate(self):
        if any(
            type(v) is not int or v < 0
            for v in (self.solver_iterations, self.component_calls, self.derivative_calls)
        ):
            raise ValueError("load work counters must be nonnegative integers")


@dataclass(frozen=True)
class LoadWorkReceipt(Record):
    schema: Literal["utility-trusted-load-work-v1"]
    grant_digest: str
    scorer_digest: str
    source_binding_digest: str
    policy_digest: str
    score_digest: str
    private_result_digest: str
    attempted_model_starts: int
    completed_model_starts: int
    total_inner_work: CounterWork | None
    known_completed_inner_work: CounterWork
    last_attempt_inner_work_unknown: bool
    task_admitted: Literal[False]
    private_boundary_qualified: Literal[False]
    os_deadline_qualified: Literal[False]
    aggregate_rss_qualified: Literal[False]
    automatic_retries: Literal[0]
    derivative_counter_scope: (
        Literal["component _linearize invocations, including Newton linearization; not FLOPs"]
        | None
    ) = None

    def _validate(self):
        for value in (
            self.grant_digest,
            self.scorer_digest,
            self.source_binding_digest,
            self.policy_digest,
            self.score_digest,
            self.private_result_digest,
        ):
            sha256(value)
        a, c = self.attempted_model_starts, self.completed_model_starts
        if type(a) is not int or type(c) is not int or not 1 <= a <= 24 or not 0 <= c <= a:
            raise ValueError("load work counts exceed supported case profile")
        if self.known_completed_inner_work.solver_iterations > 100 * c:
            raise ValueError("load work exceeds reserved solver allowance")
        if self.total_inner_work is not None:
            if (
                a != 24
                or c != 24
                or self.last_attempt_inner_work_unknown
                or self.known_completed_inner_work != self.total_inner_work
                or self.derivative_counter_scope != COUNTER_SCOPE
            ):
                raise ValueError("complete load work fields disagree")
        elif (
            c != a - 1
            or not self.last_attempt_inner_work_unknown
            or self.derivative_counter_scope is not None
        ):
            raise ValueError("failed load work must retain its unknown last attempt")


@dataclass(frozen=True)
class LoadCostRegistration(Record):
    schema: Literal["utility-load-cost-registration-v1"]
    binding_artifact: ArtifactRef
    callback_source_digest: str
    policy: LoadScorePolicy

    @classmethod
    def from_dict(cls, value):
        if (
            cls is LoadCostRegistration
            and isinstance(value, Mapping)
            and value.get("schema") == "utility-load-cost-registration-v2"
        ):
            from .load_container_costs import ContainerLoadCostRegistration

            return ContainerLoadCostRegistration.from_dict(value)
        return super().from_dict(value)

    def _validate(self):
        sha256(self.callback_source_digest)

    @property
    def outcome(self):
        p = self.policy
        return OutcomeSpec(
            "engineering-outcome-v1",
            p.outcome,
            p.units,
            "minimize",
            "mean",
            digest({"kernel": p.scorer_source_digest, "aggregation": "uniform-24-mean"}),
        )

    @property
    def code_digest(self):
        return digest(
            {
                "schema": "utility-trusted-load-callback-v1",
                "source": self.callback_source_digest,
                "kernel_policy": self.policy.digest,
                "expected_model": self.policy.expected_model_digest,
                "outcome": self.outcome.digest,
            }
        )


def _charged_scope(store, grant, registration):
    if type(grant) is not ConfirmationGrant or not isinstance(registration, LoadCostRegistration):
        raise ValueError("load costs need a typed grant and pinned registration")
    state = store.replay()
    selected = validate_grant(store, grant, state["frozen"])
    fixed = read_binding(store, registration.binding_artifact)
    if (
        grant.scorer_digest != scorer_identity(fixed, registration.code_digest)
        or grant.partition_digest != fixed.partition_policy_digest
        or grant.outcome_digest != registration.outcome.digest
    ):
        raise ValueError("load cost source or scorer registration differs from grant")
    bound = read_selected_state(store.root, selected.selected_state)
    if (
        bound.model.digest != registration.policy.expected_model_digest
        or set(bound.configuration) != {"source_current"}
        or type(bound.configuration["source_current"]) not in (int, float)
        or not 0.01 <= bound.configuration["source_current"] <= 0.1
    ):
        raise ValueError("load cost model or selected current differs")
    cell = next(c for c in store.spec.cells if c.digest == grant.cell_digest)
    if cell.task_id != fixed.task_id or cell.regime != "fixed_evaluations":
        raise ValueError("load costs support the fixed-evaluation callback only")
    resources = {r.name: r for r in grant.resources}
    for name, limit in (("load_model_starts", 24), ("load_solver_iterations", 2400)):
        r = resources.get(name)
        if r is None or (r.units, r.limit, r.enforcement) != ("count", limit, "reservation"):
            raise ValueError("load cost grant lacks exact inner-work reservation")
    active = resources.get("active_time")
    if (
        active is None
        or (active.units, active.enforcement) != ("s", "reservation")
        or active.limit <= 0
    ):
        raise ValueError("load cost grant lacks active-time allocation")
    attempt = "confirmation-" + grant.cell_digest[:48]
    allocation, _ = state["attempts"].get(attempt, (None, None))
    if (
        allocation is None
        or allocation.phase != "confirmation"
        or allocation.child_digest != grant.digest
        or allocation.resources != grant.resources
    ):
        raise StoreError("load costs need the original charged grant")
    access = state["confirmation_accesses"].get(attempt)
    if (
        access is not None
        and _read(store.root, access, "confirmation-grant.json", ConfirmationGrant) != grant
    ):
        raise StoreError("load cost access differs from charged grant")
    receipt_id = state["confirmation_scores"].get(attempt)
    receipt = read_receipt(store.root, receipt_id) if receipt_id else None
    if receipt is not None and (
        receipt.grant_digest != grant.digest
        or receipt.access_digest != access
        or receipt.outcome_contract != registration.outcome
    ):
        raise StoreError("load cost score differs from charged grant")
    return fixed, access, receipt


def join_load_costs(store, grant, registration, *, work_artifact=None):
    """Project one original callback without scanning for or refreshing a proof.

    A supplied ArtifactRef must be pinned by the trusted evidence owner. Missing
    or changed supplied bytes are errors. Omitted proof means unknown work, even
    after a successful score. A durable work proof can retain completed work when
    the suite score commit was lost. It does not recover or publish a score.

    Full counters, known-completed subsets and reservations have distinct names.
    Do not add them together. These records also do not replace callback duration,
    OS/process receipts, CPU/RSS, human effort or provider costs. Combining these
    records with generic confirmation costs preserves those remaining unknowns.
    """
    if getattr(registration, "schema", None) == "utility-load-cost-registration-v2":
        from .load_container_costs import join_container_load_costs

        return join_container_load_costs(store, grant, registration, work_artifact=work_artifact)
    fixed, access, receipt = _charged_scope(store, grant, registration)
    work = None
    if work_artifact is not None:
        if (
            not isinstance(work_artifact, ArtifactRef)
            or work_artifact.path != f"{WORK_DIRECTORY}/{grant.digest}.json"
            or work_artifact.media_type != "application/json"
            or work_artifact.producer != "engineering-load-work"
            or work_artifact.metadata
            or access is None
        ):
            raise ValueError("load cost proof role or active access differs")
        work = LoadWorkReceipt.from_json(
            read_bytes(store.root, work_artifact, max_bytes=65536).decode()
        )
        if (
            work.grant_digest != grant.digest
            or work.scorer_digest != grant.scorer_digest
            or work.source_binding_digest != fixed.digest
            or work.policy_digest != registration.policy.digest
        ):
            raise ValueError("load cost work is bound to another callback")
        if receipt is not None:
            if (
                work.score_digest != receipt.score.digest
                or ((work.total_inner_work is None) != (receipt.score.status == "model_failure"))
                or receipt.score.status not in ("success", "scientific_infeasible", "model_failure")
            ):
                raise ValueError("load cost work differs from committed score")
    return _project_work_costs(grant, work)


def _project_work_costs(grant, work):
    """Use stable physical IDs for both callback versions and missing evidence."""
    total = work.total_inner_work if work else None
    known = work.known_completed_inner_work if work else None
    quantities = [
        ("load_model_start_reservations", 24),
        ("load_solver_iteration_reservations", 2400),
        ("load_case_attempts", work.attempted_model_starts if work else None),
        ("load_completed_evaluations", work.completed_model_starts if work else None),
        ("load_model_starts", 24 if total else None),
    ]
    for raw, resource in (
        ("solver_iterations", "solver_iterations"),
        ("component_calls", "component_calls"),
        ("derivative_calls", "component_linearize_calls"),
    ):
        quantities.extend(
            [
                ("load_" + resource, getattr(total, raw) if total else None),
                ("load_known_completed_" + resource, getattr(known, raw) if known else None),
            ]
        )
    # Stable physical identity prevents double charging after proof acquisition,
    # lost acknowledgments, changed ArtifactRef metadata or later score commits.
    return tuple(
        CostRecord(
            "load-cost-" + digest({"grant": grant.digest, "resource": name})[:48],
            grant.digest,
            "confirmation",
            name,
            "count",
            quantity,
            (grant.cell_digest,),
            (1.0,),
        )
        for name, quantity in quantities
    )


@dataclass(frozen=True)
class LoadCostInput(Record):
    grant: ConfirmationGrant
    registration: LoadCostRegistration
    work_artifact: ArtifactRef | None


@dataclass(frozen=True)
class CostEvidenceSpec(Record):
    schema: Literal["utility-cost-inputs-v1"]
    suite_digest: str
    load_callbacks: tuple[LoadCostInput, ...]

    @classmethod
    def from_dict(cls, value):
        if (
            cls is CostEvidenceSpec
            and isinstance(value, Mapping)
            and value.get("schema") == "utility-cost-inputs-v2"
        ):
            return DomainCostEvidenceSpec.from_dict(value)
        return super().from_dict(value)

    def _validate(self):
        sha256(self.suite_digest)
        if any(c.grant.suite_digest != self.suite_digest for c in self.load_callbacks) or len(
            {c.grant.cell_digest for c in self.load_callbacks}
        ) != len(self.load_callbacks):
            raise ValueError("cost inputs need unique callback cells from their declared suite")


@dataclass(frozen=True, kw_only=True)
class DomainCostEvidenceSpec(CostEvidenceSpec):
    schema: Literal["utility-cost-inputs-v2"]
    wind_callbacks: tuple[WindCostInput, ...]

    def _validate(self):
        super()._validate()
        callbacks = (*self.load_callbacks, *self.wind_callbacks)
        if any(c.grant.suite_digest != self.suite_digest for c in callbacks) or len(
            {c.grant.cell_digest for c in callbacks}
        ) != len(callbacks):
            raise ValueError("domain cost inputs require unique cells from their declared suite")


def join_cost_inputs(store, inputs):
    """Cover every supported charged model callback, including uncertain work."""
    if not isinstance(inputs, CostEvidenceSpec) or inputs.suite_digest != store.spec.digest:
        raise ValueError("cost inputs belong to another suite")
    before = store.replay()
    names = {"load_model_starts", "load_solver_iterations"}
    expected = {
        a.child_digest
        for a, _ in before["attempts"].values()
        if a.phase == "confirmation" and names.intersection(r.name for r in a.resources)
    }
    if {c.grant.digest for c in inputs.load_callbacks} != expected:
        raise ValueError("cost inputs must cover every charged coupled-load callback exactly")
    wind_callbacks = inputs.wind_callbacks if isinstance(inputs, DomainCostEvidenceSpec) else ()
    wind_names = {"wind_model_starts", "private_wind_reads", "private_wind_bytes"}
    expected_wind = {
        a.child_digest
        for a, _ in before["attempts"].values()
        if a.phase == "confirmation" and wind_names.intersection(r.name for r in a.resources)
    }
    if {c.grant.digest for c in wind_callbacks} != expected_wind:
        raise ValueError(
            "wind cost inputs v2 must cover every charged annual wind callback exactly"
        )
    records = tuple(
        r
        for c in inputs.load_callbacks
        for r in join_load_costs(store, c.grant, c.registration, work_artifact=c.work_artifact)
    )
    records += tuple(
        r
        for c in wind_callbacks
        for r in join_wind_costs(store, c.grant, c.registration, work_artifact=c.work_artifact)
    )
    if store.replay()["head"] != before["head"]:
        raise StoreError("suite changed during cost reconstruction")
    return records
