# Utility comparison preparation

These are blocked task drafts for Part 5, not executable run configurations.
No confirmation data have been acquired or scored by this preparation.

`source-inventory.json` hashes the implementation and dependency configuration
available during initial preparation, including uncommitted Part 3/4 sources.
It excludes raw evidence trees and is not a clean execution provenance record.
`exposure-register.json` preserves known exclusions and unknown exposure history.
The four files in `tasks/` record questions, candidate pools, checks and blockers.
Null thresholds and partitions are deliberate admission blockers, never permission
to execute with an unlimited budget or infer independent evidence.

Wind layout is the selected fourth family. The supplied Horns Rev distribution
is development evidence. A finer direction grid cannot serve as independent
weather confirmation. The engineering draft asks a new source-power design
question using the intact coupled circuit. Exposed scalar scenario bindings now
have supervised development checks. Independent scenarios still require admission.
Existing target fits cannot answer that question.

Strict suite records, parent accounting and outcome tools now exist. Freeze
executable dossiers only after development profiling, data custody review and
numeric protocol completion. Consult
`docs/implementation-plans/part-5-utility-confirmation.md` for the full gates.


Optional report figures are described in docs/utility.md. Use report --figures
in an environment containing Matplotlib, then verify the numeric data in the
base environment or use --rerender-figures for image reconstruction. The saved
figure-rehearsal-v2 examples are authored illustrations, not scientific results.
The inconsistent first illustration is retained with an invalidation notice.

The exposed engineering tool rehearsal is runnable in the optional
`interoperability` environment:

```sh
pixi run -e interoperability python -m examples.utility.rehearse_engineering_campaign \
  --output outputs/utility-engineering-campaign
```

Use an absent output directory. It runs a baseline, a registered current design
and a numerical study, then reviews and freezes the exact selected state. The
saved `development/engineering-campaign-v2` contains twelve stopped scenario
processes and offline reconstruction evidence. It does not execute suite routes
or independent confirmation. See `docs/utility.md` for the tool contract and
`docs/reviews/part-5-completion-audit.md` for remaining work.

The native SLSQP variant uses the same environment:

```sh
pixi run -e interoperability python -m examples.utility.rehearse_engineering_native \
  --output outputs/utility-engineering-native
```

The final `development/engineering-native-v2` preserves sixteen stopped outer
processes and twelve inner native model calls. Native output receives fresh
scientific checks before selection. A successful optimizer returned a design just
below the strict voltage bound, which remained ineligible. No threshold was changed.
Outer process counts, inner calls and derivative work are separate quantities.
This remains exposed development, not a conventional-versus-agent comparison.

The seven-route engineering rehearsal adds scripted advice and parent-bound role
removals:

```sh
pixi run -e interoperability python -m examples.utility.rehearse_engineering_routes \
  --output outputs/utility-engineering-routes
```

The final `development/engineering-routes-v3` uses one paired seed and the same
supplied choices for baseline, conventional, single-agent, four-role and three
mechanical-removal routes. It records 99 stopped scientific processes, 85 scripted
host calls and ten mechanical substitutions. These are code-path checks. They do
not measure LLM quality or independent utility. The producer does not freeze the
suite selection barrier or invoke confirmation, and it is not a public utility
execution-plan interface. Earlier -v1 and failed -v2 sources/journals are retained.

The declarative engineering plan uses the public utility commands and archives
selected sources/state for a separate suite freeze:

```sh
pixi run -e interoperability python -m examples.utility.rehearse_engineering_plan \
  --output outputs/utility-engineering-plan
```

This producer runs one cell, resumes the rest, checks completed resume, then
separately freezes, verifies and inspects status. It requires a fresh output path.
The plan binds source closure, interpreter/packages and case-scoped execution v2.
It uses exposed circuit data and scripted hosts. It invokes no confirmation or
provider and does not qualify mixed-family or installed-wheel execution.

The three-family producer combines exposed Leaf River prediction, OEDI solar
prediction and the circuit design question in one 21-cell suite. Each task has
baseline, conventional, single-agent, multi-agent and three role-removal routes:

```sh
pixi run -e interoperability python -m examples.utility.rehearse_mixed \
  --output outputs/utility-mixed \
  --solar-cache /path/to/existing/9068-cache
```

Use an absent output directory and the four already verified OEDI cache files.
The loader does not fetch data. Add `--prepare-only` to capture inputs and write an
unallocated suite without scientific or host execution. The full producer runs
one cell through the public CLI, resumes the remainder, checks completed resume,
then separately seals and verifies the selection manifest. This is scripted
exposed development. Wind, independent task admission and confirmation are separate
requirements. It provides no LLM or comparative utility result.

The wind parameter profile (`wind_parameters.py`) keeps turbine coordinates as
scalar parameters and preserves fixed V80 hardware, the rectangle and spacing
checks. Its model identity stays fixed across configurations. Native wind proposals
(`wind_proposal.py`) retain separate wake/gradient callback records and require a
fresh evaluation. A physically tolerated native point outside exact parameter
bounds produces no admissible configuration. Coordinates are never clipped.

The supervised wind parity probe runs in the wind environment:

```sh
pixi run -e wind python -m examples.utility.rehearse_wind_scenario \
  --output outputs/utility-wind-scenario
```

Use an absent directory. Two bounded processes evaluate the four Horns Rev corner
turbines, directly and through the adapter, under the same bundled distribution.
Completed replay launches no new process. The fixed direction step is numerical
configuration, not independent weather. This probe does not implement the public
wind route/native-process bridge or admit the wind task for confirmation.

The bounded native wind process can be rehearsed separately:

```sh
pixi run -e wind python -m examples.utility.rehearse_wind_native \
  --output outputs/utility-wind-native
```

Use an absent output directory. One reserved TOPFARM process may propose a layout.
Only an exact-domain feasible proposal receives a separately reserved fresh wind
evaluation. Callback attempts, completions, failures and unresolved work remain
separate from outer starts. Native convergence alone does not make a model eligible.
The saved development probe and guarded reader are under
`development/wind-native-process-v1` and `verification-wind-process-v1`. This is not
yet a wind route in the public utility matrix.

The public seven-route wind development rehearsal uses callback campaign v3:

```sh
pixi run -e wind python -m examples.utility.rehearse_wind_plan \
  --output outputs/utility-wind-plan
```

It shares one supplied model, parameter domain, scenario and numerical/native
recipes across scripted routes and role removals. Native callback receipts remain
separate from fresh scenario eligibility checks. This is an exposed bundled
wind-development suite, not independent weather confirmation or a utility result.

For one common four-family development suite, use the separate `utility` environment:

```sh
pixi run -e utility python -m examples.utility.rehearse_mixed --include-wind \
  --output outputs/utility-four-family --solar-cache /path/to/verified/solar/cache
```

The output must be absent and the exposed solar cache must already be available.
This prepares 28 cells with one source/lock closure and one parent selection barrier.
TOPFARM requires OpenMDAO 3.39.*, so `utility` pins 3.39.0 separately from the existing
3.41.0 interoperability profile. The old profiles and their evidence remain intact.
The installed wind execution check from exported inputs is recorded under
`verification-installed-science-v1`; it is not independent confirmation.

New wind preparations use execution v3 with bound spacing constraints. To check
rejection before model dispatch alongside one feasible supervised evaluation:

```sh
pixi run -e utility python -m examples.utility.rehearse_wind_preflight \
  --output outputs/utility-wind-preflight
```

An overlapping layout produces scientific infeasibility with unavailable outcomes
and no process reservation. Recovery verifies the original rejection receipt.
Legacy v1/v2 evidence retains its original identity and behavior. The saved probe
and offline rejection reader are under `development/wind-preflight-v1` and
`verification-preflight-v1`. This is development evidence, not independent weather
confirmation or evidence of a utility gain.

The saved four-family diagnostic figures and their full CSV exports are in
[development/diagnostics-four-family-v4](development/diagnostics-four-family-v4/README.md).
They show comparison prediction errors, circuit operating scenarios and the common
wind layout/spacing. Scripts in `scripts/utility_development_diagnostics.py` and
`scripts/render_utility_development_diagnostics.py` reproduce them from pinned
saved artifacts. A fresh installed reader reconstructed the tables outside the
checkout without models or original-source access. All views remain exposed
scripted development evidence, not independent confirmation or utility findings.

The [Claude policy evidence](verification-claude-policy-v1/README.md) records limited
macOS syscall/help/synthetic-helper probes and their failed predecessors. The
archive reader checks saved evidence after relocation without launching programs.
This is not an admitted Claude host or a live utility comparison.

The later [native loopback evidence](verification-claude-loopback-v1/README.md)
exercises the real CLI helper hook and structured-output mechanism with authored
local events. Its installed readers verify saved evidence without models or the
checkout. No provider calls, real authentication or production admission are claimed.
