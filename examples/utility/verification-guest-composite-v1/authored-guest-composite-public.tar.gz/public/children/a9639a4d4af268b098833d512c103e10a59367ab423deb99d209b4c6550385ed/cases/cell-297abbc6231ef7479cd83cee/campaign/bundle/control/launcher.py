from pathlib import Path
import runpy,sys
from autoengineering.campaign.runtime import RUNTIME_ROOT
sys.path.insert(0,str(RUNTIME_ROOT))
job=Path(sys.argv[1])
runpy.run_path(str(job.parent.parent/'bundle/authored-helper.py'),run_name='__main__')
