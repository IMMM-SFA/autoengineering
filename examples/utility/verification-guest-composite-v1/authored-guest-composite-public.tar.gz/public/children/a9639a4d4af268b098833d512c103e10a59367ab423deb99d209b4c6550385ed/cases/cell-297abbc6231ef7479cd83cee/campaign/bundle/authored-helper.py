
import json,sys
from pathlib import Path
from dataclasses import replace
import numpy as np
from autoengineering.adapters.contracts import PrepareContext,TrainingArtifactBundle
from autoengineering.campaign.artifacts import read_arrays,read_bytes,put_bytes
from autoengineering.campaign.records import ArtifactRef
from autoengineering.campaign.spec import CampaignSpec
from autoengineering.campaign import model_worker as worker
from autoengineering.utility.hydrology_training import RoutingTrainingProfile
from examples.utility.hydrology_site import HydrologySite
from examples.utility.hydrology_learned import LearnedRoutingAdapter,load_training
path=Path(sys.argv[1]);job=json.loads(path.read_text());root=Path(job['bundle_root'])
spec=CampaignSpec.from_yaml(path.parent.parent/'campaign.yaml')
config=json.loads((root/'authored-config.json').read_text())
site=HydrologySite.from_dict(config['site']);profile=RoutingTrainingProfile.from_dict(config['profile'])
context=PrepareContext.from_dict(job['context'])
frozen=None
if config['frozen'] is not None:
 ref=ArtifactRef.from_dict(config['frozen'])
 frozen=load_training(root,ref)
 bundle_ref=ArtifactRef.from_json(ref.metadata['training_bundle'])
 bundle=TrainingArtifactBundle.from_json(read_bytes(root,bundle_ref).decode())
 scratch=Path(context.scratch_path);(scratch/'artifacts').mkdir(mode=0o700,exist_ok=True)
 for item in (bundle.primary,*bundle.companions,bundle_ref):
  saved=put_bytes(scratch,read_bytes(root,item),name=Path(item.path).name,
      media_type=item.media_type,producer=item.producer)
  assert saved.path==item.path
 import scipy.optimize
 def forbidden(*args,**kwargs):raise AssertionError('frozen helper retrained')
 scipy.optimize.least_squares=forbidden
original_registry=worker.registry()
class Registry:
 def validate(self,*args):original_registry.validate(*args)
 def create(self,adapter_id):
  original_registry.create(adapter_id)
  return LearnedRoutingAdapter(site,profile,frozen)
worker.registry=lambda:Registry()
worker.main(path)
