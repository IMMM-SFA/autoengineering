"""Bounded macOS private JSON-vector scorer using existing sandbox/supervision.

The profile scores frozen predictions only. It does not import models, train,
fetch labels, or qualify any host's access to the private directory.
"""

from __future__ import annotations

import hashlib
import math
import subprocess
import sys
from pathlib import Path

from autoengineering.agents.process import supervise_process, recover_completed_process
from autoengineering.agents.sandbox import MacOSBoundary, BoundaryLimits
from autoengineering.campaign.artifacts import read_bytes, confined_file
from autoengineering.campaign.serialization import canonical_json, digest, unique_json
from autoengineering.campaign.store import checked_directory, durable_write, StoreError
from .scoring import PublicScore


class PrivateRMSEScorer:
    def __init__(
        self,
        public_root,
        private_root,
        *,
        labels,
        predictions,
        partition_digest,
        outcome_contract,
        timeout_seconds=5.0,
        limits=BoundaryLimits(),
    ):
        self.public_root, self.private_root = (
            checked_directory(public_root),
            checked_directory(private_root),
        )
        if self.private_root.is_relative_to(self.public_root) or self.public_root.is_relative_to(
            self.private_root
        ):
            raise StoreError("private scoring scope must be separate from the public suite")
        if outcome_contract.name != "rmse" or outcome_contract.direction != "minimize":
            raise ValueError("private vector profile supports registered minimized RMSE only")
        if type(timeout_seconds) not in (float, int) or not 0 < timeout_seconds <= 60:
            raise ValueError("private scoring needs a positive timeout of at most 60 seconds")
        self.labels, self.predictions = labels, predictions
        self.partition_digest, self.outcome_contract = partition_digest, outcome_contract
        self.timeout, self.limits = float(timeout_seconds), limits
        self.boundary = MacOSBoundary()  # No permissive fallback on other platforms.
        if not data_limit_available(self.limits.memory_bytes):
            raise StoreError("private scoring memory boundary is unqualified on this platform")
        self.worker = Path(__file__).with_name("private_score_worker.py")
        self.worker_bytes = confined_file(self.worker.parent, self.worker.name).read_bytes()
        # Custodian-provided digest metadata binds registration. Opening private
        # labels is a scoring access, never constructor or recovery work.
        self.identity = digest(
            {
                "profile": "private-json-rmse-macos-v2",
                "parent_source": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                "labels": labels.sha256,
                "predictions": predictions.sha256,
                "partition": partition_digest,
                "outcome": outcome_contract.digest,
                "worker": hashlib.sha256(self.worker_bytes).hexdigest(),
                "boundary": self.boundary.identity(self.private_root, limits),
                "timeout": self.timeout,
            }
        )

    def _scope(self, grant, model):
        if (grant.scorer_digest, grant.partition_digest, grant.outcome_digest) != (
            self.identity,
            self.partition_digest,
            self.outcome_contract.digest,
        ):
            raise StoreError("private scorer grant differs from registration")
        active = next((r for r in grant.resources if r.name == "active_time"), None)
        if (
            active is None
            or active.units != "s"
            or active.enforcement != "reservation"
            or active.limit < self.timeout + 0.4
        ):
            raise StoreError("private scorer needs reserved time covering timeout and stop grace")
        if model.sha256 != grant.model_digest:
            raise StoreError("private scorer model differs from grant")
        return self.private_root / grant.digest

    def __call__(self, grant, model):
        root = self._scope(grant, model)
        if root.exists() or root.is_symlink():
            raise StoreError("private scorer attempt already exists; explicit recovery required")
        document = unique_json(read_bytes(self.public_root, self.predictions).decode())
        if not isinstance(document, dict) or set(document) != {
            "model_sha256",
            "partition_digest",
            "selection_digest",
            "prediction",
        }:
            raise StoreError("frozen predictions have invalid schema")
        if (
            document["model_sha256"],
            document["partition_digest"],
            document["selection_digest"],
        ) != (model.sha256, self.partition_digest, grant.selection_digest):
            raise StoreError("frozen predictions differ from selected model or partition")
        predicted = document["prediction"]
        if (
            not isinstance(predicted, list)
            or not predicted
            or any(type(v) not in (int, float) or not math.isfinite(v) for v in predicted)
        ):
            raise StoreError("frozen public predictions must be a nonempty finite numeric vector")
        job = canonical_json(
            {
                "prediction": predicted,
                "outcome": self.outcome_contract.name,
                "units": self.outcome_contract.units,
            }
        ).encode()
        root.mkdir(mode=0o700)
        work = root / "workspace"
        work.mkdir(mode=0o700)
        durable_write(work / "score.py", self.worker_bytes)
        durable_write(work / "job.json", job)
        durable_write(
            root / "binding.json",
            canonical_json(
                {"grant": grant.digest, "scorer": self.identity, "model": model.sha256}
            ).encode(),
        )
        # Persist access intent before the first private-byte read. An interrupted
        # read/write remains an attempt; the existing root prevents a free retry.
        durable_write(
            root / "private-access.json",
            canonical_json(self._access_binding(grant, model, job)).encode(),
        )
        labels = read_bytes(self.private_root, self.labels)
        durable_write(work / "labels.json", labels)
        result = supervise_process(
            self.boundary.command(work, "score.py", self.limits),
            directory=root / "process",
            cwd=work,
            environment={},
            nonce="score-" + grant.digest[:32],
            stdin=b"",
            timeout_seconds=self.timeout,
            max_output_bytes=self.limits.output_bytes,
            on_launch=lambda identity: durable_write(
                root / "launch.json", canonical_json(identity).encode()
            ),
            parent_watchdog=True,
        )
        if (
            result.status != "completed"
            or result.returncode != 0
            or not result.stopped
            or result.truncated
        ):
            raise StoreError("private scorer did not produce a verified bounded result")
        score = PublicScore.from_json(result.stdout.decode())
        if (score.outcome, score.units) != (
            self.outcome_contract.name,
            self.outcome_contract.units,
        ):
            raise StoreError("private scorer returned incompatible public semantics")
        durable_write(root / "public-score.json", score.to_json().encode())
        return score

    def _access_binding(self, grant, model, job):
        return {
            "schema": "private-json-rmse-access-v2",
            "grant": grant.digest,
            "scorer": self.identity,
            "model": model.sha256,
            "labels_sha256": self.labels.sha256,
            "predictions_sha256": self.predictions.sha256,
            "worker_sha256": hashlib.sha256(self.worker_bytes).hexdigest(),
            "public_job_sha256": hashlib.sha256(job).hexdigest(),
        }

    def recover(self, grant, model):
        """Read an already-completed private worker; never restart it or open labels."""
        root = checked_directory(self._scope(grant, model))
        binding = unique_json(confined_file(root, "binding.json").read_text())
        if binding != {"grant": grant.digest, "scorer": self.identity, "model": model.sha256}:
            raise StoreError("private recovery binding changed")
        work = checked_directory(root / "workspace")
        # These are public inputs and fixed worker source, not labels.
        job = confined_file(work, "job.json").read_bytes()
        access = unique_json(confined_file(root, "private-access.json").read_text())
        if access != self._access_binding(grant, model, job):
            raise StoreError("private recovery access binding changed")
        if confined_file(work, "score.py").read_bytes() != self.worker_bytes:
            raise StoreError("private recovery worker changed")
        expected_job = {
            "command": list(self.boundary.command(work, "score.py", self.limits)),
            "cwd": str(work),
            "environment": {},
            "keep_group_leader": True,
            "owner_lease": "pipe-eof-v1",
        }
        if unique_json(confined_file(root / "process", "job.json").read_text()) != expected_job:
            raise StoreError("private recovery process differs from original boundary")
        result = recover_completed_process(
            root / "process",
            nonce="score-" + grant.digest[:32],
            max_output_bytes=self.limits.output_bytes,
        )
        if (
            result.status != "completed"
            or result.returncode != 0
            or not result.stopped
            or result.truncated
        ):
            raise StoreError("private process completion remains uncertain")
        raw = result.stdout
        score = PublicScore.from_json(raw.decode())
        if (score.outcome, score.units) != (
            self.outcome_contract.name,
            self.outcome_contract.units,
        ):
            raise StoreError("private recovery public semantics changed")
        return score


def data_limit_available(memory_bytes):
    """Test the requested kernel limit without reading private data or running a model."""
    code = (
        "import resource; resource.setrlimit(resource.RLIMIT_DATA, "
        f"({int(memory_bytes)},{int(memory_bytes)}))"
    )
    try:
        result = subprocess.run(
            (sys.executable, "-I", "-S", "-c", code), capture_output=True, timeout=2, check=False
        )
        return result.returncode == 0
    except (OSError, subprocess.TimeoutExpired):
        return False
