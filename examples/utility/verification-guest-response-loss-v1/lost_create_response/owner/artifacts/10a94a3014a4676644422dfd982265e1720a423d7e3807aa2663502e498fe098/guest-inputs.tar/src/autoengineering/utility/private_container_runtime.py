"""Explicit local Unix-socket candidate runtime for the fixed private scorer.

No image pull, remote endpoint, generated code, registry activation or scientific
admission is provided. The caller owns data admission and confirmation grants.
"""

from __future__ import annotations

import argparse
import hashlib
import http.client
import json
import math
import os
from pathlib import Path
import re
import select
import socket
import stat
import struct
import subprocess
import sys
import time
import uuid

IMAGE = "sha256:a0f57064cbdcd6285fa45f51237ab0b35ea8ebaed06a1f5973e89e19dfb86704"
PURPOSE = "utility-private-rmse-container-candidate-v1"
MODES = ("score",)
MEMORY = 67108864
OUTPUT = 16384


class Refused(ValueError):
    pass


def encode(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()


def decode(raw):
    """Read one finite JSON document without ambiguous duplicate fields."""

    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise Refused("duplicate runtime JSON field")
            result[key] = value
        return result

    def number(value):
        parsed = float(value)
        if not math.isfinite(parsed):
            raise Refused("nonfinite runtime JSON number")
        return parsed

    def integer(value):
        parsed = int(value)
        try:
            math.isfinite(parsed)
        except OverflowError:
            raise Refused("runtime JSON integer exceeds finite numeric range") from None
        return parsed

    def constant(_value):
        raise Refused("nonfinite runtime JSON constant")

    try:
        return json.loads(
            raw,
            object_pairs_hook=pairs,
            parse_float=number,
            parse_int=integer,
            parse_constant=constant,
        )
    except (ValueError, UnicodeError, RecursionError):
        raise Refused("invalid runtime JSON document") from None


def validate_output(raw):
    """Validate the fixed worker envelope before accepting any result."""
    if not isinstance(raw, bytes) or not 0 < len(raw) <= OUTPUT:
        raise Refused("scorer output exceeds its bound")
    result = decode(raw)
    if (
        not isinstance(result, dict)
        or set(result)
        != {
            "schema",
            "mode",
            "output_limit_bytes",
            "captured_bytes",
            "child_signal",
            "child_exit_code",
            "output_limited",
            "private_scoring_qualified",
            "score",
        }
        or result["schema"] != "private-container-output-v1"
        or result["mode"] != "score"
        or result["private_scoring_qualified"] is not False
        or type(result["output_limit_bytes"]) is not int
        or result["output_limit_bytes"] != OUTPUT
        or result["output_limited"] is not False
        or type(result["child_exit_code"]) is not int
        or result["child_exit_code"] != 0
        or result["child_signal"] is not None
        or type(result["captured_bytes"]) is not int
        or not 0 < result["captured_bytes"] < OUTPUT
    ):
        raise Refused("scorer output is failed, malformed or limited")
    score = result["score"]
    if (
        not isinstance(score, dict)
        or set(score) != {"status", "outcome", "units", "value", "feasible"}
        or score["outcome"] != "rmse"
        or not isinstance(score["units"], str)
        or not score["units"].strip()
    ):
        raise Refused("fixed scorer result schema differs")
    if score["status"] == "success":
        if (
            type(score["value"]) not in (int, float)
            or not math.isfinite(score["value"])
            or score["value"] < 0
            or score["feasible"] is not True
        ):
            raise Refused("fixed scorer success is invalid")
    elif (
        score["status"] not in ("infrastructure_failure", "insufficient_data")
        or score["value"] is not None
        or score["feasible"] is not None
    ):
        raise Refused("fixed scorer failure semantics differ")
    return result


def write(path, value):
    with path.open("xb") as stream:
        stream.write(encode(value) + b"\n")
        stream.flush()
        os.fsync(stream.fileno())
    descriptor = os.open(path.parent, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_regular(path, limit):
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    try:
        info = os.fstat(fd)
        if not stat.S_ISREG(info.st_mode) or info.st_size > limit:
            raise Refused("runtime evidence must be a bounded regular file")
        with os.fdopen(fd, "rb", closefd=False) as stream:
            raw = stream.read(limit + 1)
        if len(raw) > limit:
            raise Refused("runtime evidence exceeds its bound")
        return raw
    finally:
        os.close(fd)


class Connection(http.client.HTTPConnection):
    def __init__(self, socket_path, **kwargs):
        super().__init__("localhost", **kwargs)
        self.socket_path = socket_path

    def connect(self):
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.settimeout(self.timeout)
        self.sock.connect(self.socket_path)


class API:
    def __init__(self, socket_path, version=""):
        if not Path(socket_path).is_absolute() or "\x00" in str(socket_path):
            raise Refused("runtime requires an explicit local Unix socket")
        self.socket_path = str(socket_path)
        if version and not re.fullmatch(r"1\.[0-9]{1,3}", version):
            raise Refused("invalid local API version")
        self.prefix = "/v" + version if version else ""

    def request(self, method, path, value=None, *, limit=262144):
        connection = Connection(self.socket_path, timeout=3)
        try:
            connection.request(
                method,
                self.prefix + path,
                body=encode(value) if value else None,
                headers={"Content-Type": "application/json"},
            )
            response = connection.getresponse()
            raw = response.read(limit + 1)
            if len(raw) > limit:
                raise Refused("local API response exceeds bound")
            return response.status, raw
        finally:
            connection.close()

    def json(self, method, path, value=None, *, expected=200):
        status, raw = self.request(method, path, value)
        if status != expected:
            raise Refused("local API request did not complete")
        return decode(raw)

    def inspect(self, cid):
        if not re.fullmatch(r"[0-9a-f]{64}", cid):
            raise Refused("invalid owned container ID")
        status, raw = self.request("GET", f"/containers/{cid}/json")
        if status == 404:
            return None
        if status != 200:
            raise Refused("container absence is unverified")
        return decode(raw)

    def inspect_named(self, nonce):
        if not re.fullmatch(r"[0-9a-f]{32}", nonce):
            raise Refused("invalid original creation nonce")
        status, raw = self.request("GET", f"/containers/ae-private-rmse-{nonce}/json")
        if status == 404:
            return None
        if status != 200:
            raise Refused("original creation observation is unverified")
        return decode(raw)


def configuration(nonce, mode, stage):
    if not re.fullmatch(r"[0-9a-f]{32}", nonce) or mode not in MODES:
        raise Refused("invalid synthetic control")
    return {
        "Image": IMAGE,
        "User": "65534:65534",
        "WorkingDir": "/qualification",
        "Entrypoint": ["python3", "-I", "-S", "-B", "/qualification/private_container_worker.py"],
        "Cmd": ["score"],
        "AttachStdout": True,
        "AttachStderr": True,
        "Labels": {"org.autoengineering.purpose": PURPOSE, "org.autoengineering.nonce": nonce},
        "HostConfig": {
            "NetworkMode": "none",
            "ReadonlyRootfs": True,
            "CapDrop": ["ALL"],
            "SecurityOpt": ["no-new-privileges"],
            "Memory": MEMORY,
            "MemorySwap": MEMORY,
            "NanoCpus": 1000000000,
            "PidsLimit": 16,
            "CgroupnsMode": "private",
            "IpcMode": "none",
            "Privileged": False,
            "RestartPolicy": {"Name": "no", "MaximumRetryCount": 0},
            "Mounts": [
                {"Type": "bind", "Source": str(stage), "Target": "/qualification", "ReadOnly": True}
            ],
            "Tmpfs": {"/tmp": "rw,noexec,nosuid,nodev,size=4m"},
            "LogConfig": {"Type": "json-file", "Config": {"max-size": "16k", "max-file": "1"}},
        },
    }


def verify_identity(value, plan):
    expected = configuration(plan["nonce"], plan["mode"], Path(plan["stage"]))
    if (
        value["Id"] != plan["container_id"]
        or value["Image"] != IMAGE
        or value["Name"] != "/ae-private-rmse-" + plan["nonce"]
    ):
        raise Refused("container identity differs")
    config = value["Config"]
    if any(config.get("Labels", {}).get(k) != v for k, v in expected["Labels"].items()):
        raise Refused("container owner binding differs")


def verify_owned(value, plan):
    verify_identity(value, plan)
    expected = configuration(plan["nonce"], plan["mode"], Path(plan["stage"]))
    config, host = value["Config"], value["HostConfig"]
    for key in ("User", "WorkingDir", "Entrypoint", "Cmd", "Image"):
        if config[key] != expected[key]:
            raise Refused("container command differs")
    if any(config.get("Labels", {}).get(k) != v for k, v in expected["Labels"].items()):
        raise Refused("container owner binding differs")
    for key in (
        "NetworkMode",
        "ReadonlyRootfs",
        "Memory",
        "MemorySwap",
        "NanoCpus",
        "PidsLimit",
        "CgroupnsMode",
        "IpcMode",
        "Privileged",
        "CapDrop",
        "SecurityOpt",
        "Tmpfs",
        "LogConfig",
        "RestartPolicy",
    ):
        if host[key] != expected["HostConfig"][key]:
            raise Refused("container resource or isolation settings differ")
    if host.get("PidMode", "") or host.get("Devices") or host.get("Binds"):
        raise Refused("container has unapproved host access")
    mounts = value["Mounts"]
    binds = [m for m in mounts if m["Type"] == "bind"]
    extras = [m for m in mounts if m["Type"] != "bind"]
    if len(binds) != 1 or any(
        binds[0].get(k) != v
        for k, v in {
            "Type": "bind",
            "Source": plan["stage"],
            "Destination": "/qualification",
            "RW": False,
        }.items()
    ):
        raise Refused("container mounts differ")
    if extras and (
        len(extras) != 1
        or extras[0].get("Type") != "tmpfs"
        or extras[0].get("Destination") != "/tmp"
        or extras[0].get("RW") is not True
    ):
        raise Refused("container has an unapproved extra mount")


def verify_lifecycle(value, plan, *, completed):
    """Require a single unpaused created/exited observation with strict state types."""
    verify_owned(value, plan)
    state = value["State"]
    if (
        state.get("Status") != ("exited" if completed else "created")
        or state.get("Running") is not False
        or state.get("Paused") is not False
        or type(state.get("Pid")) is not int
        or state["Pid"] != 0
        or type(value.get("RestartCount")) is not int
        or value["RestartCount"] != 0
        or (
            completed
            and (
                type(state.get("ExitCode")) is not int
                or state["ExitCode"] != 0
                or state.get("OOMKilled") is not False
            )
        )
    ):
        raise Refused("original scorer lifecycle is incomplete or inconsistent")


def cleanup(api, plan, directory, reason):
    before = api.inspect(plan["container_id"])
    if before is not None:
        # A resource-setting mismatch must prevent start, not prevent cleanup of
        # the exact container we own. Never remove an unrelated container.
        verify_identity(before, plan)
        before_path = directory / "cleanup-before.json"
        if before_path.exists() or before_path.is_symlink():
            verify_identity(decode(read_regular(before_path, 262144)), plan)
            before_path = directory / ("cleanup-before-" + uuid.uuid4().hex + ".json")
        write(before_path, before)
        status, _ = api.request("DELETE", f"/containers/{plan['container_id']}?force=true")
        if status not in (204, 404):
            raise Refused("owned container removal is unverified")
    if api.inspect(plan["container_id"]) is not None:
        raise Refused("owned container still exists")
    receipt = {
        "container_id": plan["container_id"],
        "nonce": plan["nonce"],
        "reason": reason,
        "removed": True,
    }
    try:
        write(directory / "cleanup.json", receipt)
    except FileExistsError:
        prior = decode(read_regular(directory / "cleanup.json", 262144))
        if (
            prior["container_id"] != receipt["container_id"]
            or prior["nonce"] != receipt["nonce"]
            or prior["removed"] is not True
        ):
            raise Refused("original cleanup receipt differs") from None


def logs(raw):
    output = {1: bytearray(), 2: bytearray()}
    while raw:
        if len(raw) < 8:
            raise Refused("truncated container output frame")
        stream, reserved, size = raw[0], raw[1:4], struct.unpack(">I", raw[4:8])[0]
        if stream not in output or reserved != b"\0\0\0" or len(raw) < size + 8:
            raise Refused("invalid container output frame")
        output[stream].extend(raw[8 : 8 + size])
        raw = raw[8 + size :]
    if sum(map(len, output.values())) > OUTPUT:
        raise Refused("container output exceeds bound")
    return bytes(output[1]), bytes(output[2])


def watchdog(plan_path, owner_fd):
    directory = plan_path.parent
    plan = decode(plan_path.read_bytes())
    if (
        plan["runtime_sha256"] != sha(Path(__file__).read_bytes())
        or not stat.S_ISFIFO(os.fstat(owner_fd).st_mode)
        or Path(plan["stage"]) != directory / "stage"
    ):
        raise Refused("watchdog source or owner binding differs")
    api = API(plan["socket_path"], plan["api_version"])
    value = api.inspect(plan["container_id"])
    if value is None:
        raise Refused("original created container is absent")
    verify_owned(value, plan)
    write(
        directory / "watchdog-ready.json",
        {
            "container_id": plan["container_id"],
            "nonce": plan["nonce"],
            "watchdog_pid": os.getpid(),
        },
    )
    deadline = time.monotonic() + 10
    reason = "deadline"
    while time.monotonic() < deadline:
        ready, _, _ = select.select(
            [owner_fd], [], [], min(0.1, max(0, deadline - time.monotonic()))
        )
        if ready and not os.read(owner_fd, 1):
            reason = "owner_pipe_eof"
            break
    cleanup(api, plan, directory, reason)


class FixedScorerRuntime:
    """Candidate API boundary. No constructor or offline recovery opens labels."""

    def __init__(self, socket_path: Path, *, server_sha256: str):
        self.socket_path = str(socket_path)
        API(self.socket_path)  # Validate configuration without opening a socket.
        if not re.fullmatch(r"[0-9a-f]{64}", server_sha256):
            raise Refused("runtime needs an explicit server fingerprint")
        self.server_sha256 = server_sha256
        self.runtime_bytes = Path(__file__).read_bytes()
        self.wrapper_bytes = Path(__file__).with_name("private_container_worker.py").read_bytes()
        self.worker_bytes = Path(__file__).with_name("private_score_worker.py").read_bytes()
        self.identity = self._fingerprint()

    def _fingerprint(self):
        return sha(
            encode(
                {
                    "profile": PURPOSE,
                    "socket": self.socket_path,
                    "server": self.server_sha256,
                    "image": IMAGE,
                    "runtime": sha(self.runtime_bytes),
                    "wrapper": sha(self.wrapper_bytes),
                    "worker": sha(self.worker_bytes),
                    "memory": MEMORY,
                    "output": OUTPUT,
                    "watchdog_seconds": 10,
                }
            )
        )

    def _validate_identity(self):
        if self.identity != self._fingerprint():
            raise Refused("registered container runtime configuration changed")

    def preflight(self):
        """Read daemon/image metadata before any private-byte access."""
        self._validate_identity()
        value = API(self.socket_path).json("GET", "/version")
        if sha(encode(value)) != self.server_sha256:
            raise Refused("local daemon differs from registered runtime")
        api = API(self.socket_path, value["ApiVersion"])
        image = api.json("GET", "/images/" + IMAGE + "/json")
        if image["Id"] != IMAGE or image["Os"] != "linux" or image["Architecture"] != "arm64":
            raise Refused("cached pinned local ARM64 image is unavailable")
        return value["ApiVersion"]

    def run(self, root: Path, *, api_version: str, job_sha256: str, labels_sha256: str):
        """Run one already-staged private attempt. Existing execution is never reused."""
        self._validate_identity()
        if (
            not root.is_absolute()
            or any(p.is_symlink() for p in (root, *root.parents))
            or root.stat().st_uid != os.geteuid()
            or stat.S_IMODE(root.stat().st_mode) & 0o077
        ):
            raise Refused("private runtime root must be owned and private")
        directory = root / "container"
        directory.mkdir(mode=0o700)
        stage = directory / "stage"
        stage.mkdir(mode=0o700)
        for name in ("job.json", "labels.json"):
            source = root / "workspace" / name
            # All reads happen after the scorer's durable access intent. The
            # derived private stage is never a grant to an agent/model worker.
            (stage / name).write_bytes(read_regular(source, 1048576))
        for name, raw in (
            ("private_score_worker.py", self.worker_bytes),
            ("private_container_worker.py", self.wrapper_bytes),
        ):
            (stage / name).write_bytes(raw)
        for path in stage.iterdir():
            path.chmod(0o444)
        stage.chmod(0o555)
        source_hashes = {p.name: sha(read_regular(p, 1048576)) for p in stage.iterdir()}
        if source_hashes["job.json"] != job_sha256 or source_hashes["labels.json"] != labels_sha256:
            raise Refused("staged scoring inputs differ from the durable access intent")
        write(directory / "stage-hashes.json", source_hashes)
        (directory / "runtime.py").write_bytes(self.runtime_bytes)
        (directory / "runtime.py").chmod(0o500)
        nonce = uuid.uuid4().hex
        config = configuration(nonce, "score", stage)
        api = API(self.socket_path, api_version)
        write(directory / "create-intent.json", config)
        pending = {
            "schema": "private-container-creation-pending-v1",
            "nonce": nonce,
            "mode": "score",
            "stage": str(stage),
            "api_version": api_version,
            "socket_path": self.socket_path,
            "runtime_sha256": sha(self.runtime_bytes),
            "runtime_identity": self.identity,
            "job_sha256": job_sha256,
            "labels_sha256": labels_sha256,
            "configuration_sha256": sha(encode(config)),
        }
        # Durable ownership precedes the request, including an unknown/lost ack.
        write(directory / "creation-pending.json", pending)
        try:
            created = api.json(
                "POST", "/containers/create?name=ae-private-rmse-" + nonce, config, expected=201
            )
            cid = created["Id"]
            if not isinstance(cid, str) or not re.fullmatch(r"[0-9a-f]{64}", cid):
                raise Refused("create acknowledgement lacks an exact original ID")
            plan = {**pending, "container_id": cid}
            write(directory / "plan.json", plan)
            read_fd, write_fd = os.pipe()
        except BaseException:
            # There has been no start request. Try bounded cleanup of this same
            # creation only. A missing name can still be a late creation, so it
            # never proves no launch and never releases the original charge.
            try:
                self.reconcile_creation(root, stop=True)
            except Exception:
                raise Refused("container creation and original cleanup remain uncertain") from None
            raise
        child = None
        try:
            with (
                (directory / "watchdog.stdout").open("xb") as out,
                (directory / "watchdog.stderr").open("xb") as err,
            ):
                child = subprocess.Popen(
                    [
                        sys.executable,
                        "-I",
                        "-S",
                        "-B",
                        str(directory / "runtime.py"),
                        "--plan",
                        str(directory / "plan.json"),
                        "--owner-fd",
                        str(read_fd),
                    ],
                    pass_fds=(read_fd,),
                    stdout=out,
                    stderr=err,
                    start_new_session=True,
                    env={"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8"},
                )
            os.close(read_fd)
            read_fd = None
            deadline = time.monotonic() + 5
            while not (directory / "watchdog-ready.json").exists():
                if child.poll() is not None or time.monotonic() >= deadline:
                    raise Refused("watchdog did not arm before start")
                time.sleep(0.02)
            ready = decode(read_regular(directory / "watchdog-ready.json", 1024))
            if ready["container_id"] != cid or ready["nonce"] != nonce:
                raise Refused("watchdog readiness belongs to another original container")
            before = api.inspect(cid)
            verify_lifecycle(before, plan, completed=False)
            write(directory / "before-start.json", before)
            if any(
                sha(read_regular(stage / name, 1048576)) != value
                for name, value in source_hashes.items()
            ):
                raise Refused("private stage changed before start")
            write(directory / "start-intent.json", {"container_id": cid, "nonce": nonce})
            began = time.monotonic()
            status, _ = api.request("POST", f"/containers/{cid}/start")
            if status != 204:
                raise Refused("start acknowledgement is uncertain; no retry")
            deadline = time.monotonic() + 8
            while True:
                final = api.inspect(cid)
                if final is None:
                    raise Refused("original container disappeared before result reconciliation")
                verify_owned(final, plan)
                if not final["State"]["Running"]:
                    break
                if time.monotonic() >= deadline:
                    raise Refused("fixed scorer exceeded its deadline")
                time.sleep(0.05)
            lifecycle_seconds = time.monotonic() - began
            write(directory / "final-inspect.json", final)
            verify_lifecycle(final, plan, completed=True)
            status, raw = api.request(
                "GET", f"/containers/{cid}/logs?stdout=1&stderr=1", limit=32768
            )
            if status != 200:
                raise Refused("original scorer output is unavailable")
            stdout, stderr = logs(raw)
            (directory / "stdout.bin").write_bytes(stdout)
            (directory / "stderr.bin").write_bytes(stderr)
            if stderr:
                raise Refused("scorer output includes unexpected stderr")
            result = validate_output(stdout)
            write(
                directory / "result.json",
                {
                    "container_id": cid,
                    "nonce": nonce,
                    "runtime_identity": self.identity,
                    "lifecycle_seconds": lifecycle_seconds,
                    "stdout_sha256": sha(stdout),
                    "result": result,
                },
            )
        finally:
            if read_fd is not None:
                os.close(read_fd)
            os.close(write_fd)
            if child is not None:
                child.wait(timeout=15)
            if not (directory / "cleanup.json").exists():
                cleanup(api, plan, directory, "parent_reconciliation")
            if api.inspect(cid) is not None:
                raise Refused("original scorer cleanup is unresolved")
        return self.recover(root, job_sha256=job_sha256, labels_sha256=labels_sha256)

    def reconcile_creation(self, root: Path, *, stop: bool = False):
        """Observe/remove only the original creation. Never create, start or score.

        An absent name without a known original ID remains uncertain: the
        original request may commit later. stop=True explicitly permits removal
        of this owned container, including a running one. Reservations stay
        charged and this method supplies no scientific result.
        """
        self._validate_identity()
        if type(stop) is not bool:
            raise Refused("creation reconciliation stop must be explicit")
        directory = root / "container"
        if (
            not root.is_absolute()
            or any(p.is_symlink() for p in (root, *root.parents, directory))
            or directory.stat().st_uid != os.geteuid()
            or stat.S_IMODE(directory.stat().st_mode) & 0o077
        ):
            raise Refused("creation reconciliation requires its owned private directory")
        pending = decode(read_regular(directory / "creation-pending.json", 262144))
        config = decode(read_regular(directory / "create-intent.json", 262144))
        if (
            pending["schema"] != "private-container-creation-pending-v1"
            or pending["runtime_identity"] != self.identity
            or pending["runtime_sha256"] != sha(self.runtime_bytes)
            or pending["socket_path"] != self.socket_path
            or pending["configuration_sha256"] != sha(encode(config))
            or config != configuration(pending["nonce"], "score", Path(pending["stage"]))
        ):
            raise Refused("original creation intent differs from registered runtime")
        api = API(self.socket_path, pending["api_version"])
        known = None
        for name in ("plan.json", "reconciled-container-id.json"):
            path = directory / name
            if path.exists() or path.is_symlink():
                saved = decode(read_regular(path, 262144))
                if (
                    saved["nonce"] != pending["nonce"]
                    or saved["runtime_identity"] != self.identity
                    or not re.fullmatch(r"[0-9a-f]{64}", saved["container_id"])
                    or (known is not None and known != saved["container_id"])
                ):
                    raise Refused("original creation IDs or ownership differ")
                known = saved["container_id"]
        value = api.inspect(known) if known else api.inspect_named(pending["nonce"])
        if value is not None:
            cid = value["Id"]
            if not re.fullmatch(r"[0-9a-f]{64}", cid):
                raise Refused("original named creation has no exact ID")
            plan = {**pending, "container_id": known or cid}
            verify_identity(value, plan)
            known = plan["container_id"]
            saved_path = directory / "reconciled-container-id.json"
            if not saved_path.exists():
                write(
                    saved_path,
                    {
                        "container_id": known,
                        "nonce": pending["nonce"],
                        "runtime_identity": self.identity,
                    },
                )
        removed = known is not None and value is None
        if value is not None and stop:
            cleanup_path = directory / "cleanup.json"
            if cleanup_path.exists() or cleanup_path.is_symlink():
                raise Refused("recorded cleanup conflicts with an existing original container")
            cleanup(
                api,
                {**pending, "container_id": known},
                directory,
                "explicit_creation_reconciliation",
            )
            removed = True
        observation = {
            "schema": "private-container-creation-observation-v1",
            "runtime_identity": self.identity,
            "nonce": pending["nonce"],
            "container_id": known,
            "state": "removed"
            if removed
            else "observed"
            if value is not None
            else "absent_at_observation",
            "removed": removed,
            "creation_uncertain": not removed,
            "scientific_result_available": False,
        }
        write(directory / ("creation-observation-" + uuid.uuid4().hex + ".json"), observation)
        return observation

    def recover(self, root: Path, *, job_sha256: str, labels_sha256: str):
        """Offline completed-result recovery. No API, labels, create or start."""
        self._validate_identity()
        directory = root / "container"
        if not root.is_absolute() or any(
            p.is_symlink() for p in (root, *root.parents, directory, directory / "stage")
        ):
            raise Refused("saved runtime directories must be direct absolute paths")

        def document(name):
            path = directory / name
            if path.is_symlink() or not path.is_file() or path.stat().st_size > 262144:
                raise Refused("saved runtime evidence is unavailable")
            return decode(read_regular(path, 262144))

        plan = document("plan.json")
        pending = document("creation-pending.json")
        config = document("create-intent.json")
        keys = {
            "schema",
            "nonce",
            "mode",
            "stage",
            "api_version",
            "socket_path",
            "runtime_sha256",
            "runtime_identity",
            "job_sha256",
            "labels_sha256",
            "configuration_sha256",
        }
        if (
            not isinstance(pending, dict)
            or set(pending) != keys
            or not isinstance(plan, dict)
            or set(plan) != keys | {"container_id"}
            or not isinstance(plan["container_id"], str)
            or not re.fullmatch(r"[0-9a-f]{64}", plan["container_id"])
            or plan != {**pending, "container_id": plan["container_id"]}
            or pending["schema"] != "private-container-creation-pending-v1"
            or pending["mode"] != "score"
            or not isinstance(pending["nonce"], str)
            or not re.fullmatch(r"[0-9a-f]{32}", pending["nonce"])
            or not isinstance(pending["api_version"], str)
            or not re.fullmatch(r"1\.[0-9]{1,3}", pending["api_version"])
            or pending["socket_path"] != self.socket_path
            or pending["runtime_identity"] != self.identity
            or pending["runtime_sha256"] != sha(self.runtime_bytes)
            or not isinstance(pending["stage"], str)
            or not Path(pending["stage"]).is_absolute()
        ):
            raise Refused("saved original creation binding differs")
        API(self.socket_path, pending["api_version"])  # Pure validation, no socket.
        if encode(config) != encode(
            configuration(pending["nonce"], "score", Path(pending["stage"]))
        ) or pending["configuration_sha256"] != sha(encode(config)):
            raise Refused("saved original creation configuration differs")
        sources = document("stage-hashes.json")
        expected_sources = {
            "job.json": job_sha256,
            "labels.json": labels_sha256,
            "private_container_worker.py": sha(self.wrapper_bytes),
            "private_score_worker.py": sha(self.worker_bytes),
        }
        if (
            sources != expected_sources
            or plan["job_sha256"] != job_sha256
            or plan["labels_sha256"] != labels_sha256
            or sha(read_regular(directory / "stage/job.json", 1048576)) != job_sha256
        ):
            raise Refused("saved public job or private input identity differs")
        if read_regular(directory / "runtime.py", 65536) != self.runtime_bytes:
            raise Refused("saved runtime source differs")
        for name, expected in (
            ("private_container_worker.py", self.wrapper_bytes),
            ("private_score_worker.py", self.worker_bytes),
        ):
            if read_regular(directory / "stage" / name, 65536) != expected:
                raise Refused("saved fixed scorer source differs")
        verify_lifecycle(document("before-start.json"), plan, completed=False)
        verify_lifecycle(document("final-inspect.json"), plan, completed=True)
        ready = document("watchdog-ready.json")
        if (
            not isinstance(ready, dict)
            or set(ready) != {"container_id", "nonce", "watchdog_pid"}
            or type(ready["watchdog_pid"]) is not int
            or ready["watchdog_pid"] <= 0
        ):
            raise Refused("saved watchdog readiness is invalid")
        receipt, result = document("cleanup.json"), document("result.json")
        start = document("start-intent.json")
        result_keys = {"container_id", "nonce", "runtime_identity", "stdout_sha256", "result"}
        if (
            not isinstance(start, dict)
            or set(start) != {"container_id", "nonce"}
            or not isinstance(receipt, dict)
            or set(receipt) != {"container_id", "nonce", "reason", "removed"}
            or receipt["reason"]
            not in (
                "owner_pipe_eof",
                "deadline",
                "parent_reconciliation",
                "explicit_creation_reconciliation",
            )
            or not isinstance(result, dict)
            or set(result) not in (result_keys, result_keys | {"lifecycle_seconds"})
        ):
            raise Refused("saved runtime receipt schema differs")
        for bound in (receipt, result, start, ready):
            if bound["container_id"] != plan["container_id"] or bound["nonce"] != plan["nonce"]:
                raise Refused("saved receipt belongs to another original container")
        if "lifecycle_seconds" in result and (
            type(result["lifecycle_seconds"]) not in (int, float)
            or not math.isfinite(result["lifecycle_seconds"])
            or result["lifecycle_seconds"] < 0
        ):
            raise Refused("saved lifecycle duration is invalid")
        if receipt["removed"] is not True or result["runtime_identity"] != self.identity:
            raise Refused("saved original cleanup is unresolved")
        stdout = directory / "stdout.bin"
        if stdout.is_symlink() or not stdout.is_file() or stdout.stat().st_size > OUTPUT:
            raise Refused("saved bounded output is unavailable")
        raw = read_regular(stdout, OUTPUT)
        captured = validate_output(raw)
        if read_regular(directory / "stderr.bin", OUTPUT) != b"":
            raise Refused("saved scorer stderr differs")
        if sha(raw) != result["stdout_sha256"] or encode(captured) != encode(result["result"]):
            raise Refused("saved output identity differs")
        return captured["score"]

    def execution_evidence(self, root: Path, *, job_sha256: str, labels_sha256: str):
        """Export only verified original execution metadata, without label reads/API."""
        score = self.recover(root, job_sha256=job_sha256, labels_sha256=labels_sha256)
        directory = root / "container"

        def document(name):
            raw = read_regular(directory / name, 262144)
            return decode(raw), sha(raw)

        plan, _ = document("plan.json")
        before, _ = document("before-start.json")
        final, stop_digest = document("final-inspect.json")
        _, start_digest = document("start-intent.json")
        cleanup_receipt, cleanup_digest = document("cleanup.json")
        result, _ = document("result.json")
        if (
            before["State"]["Status"] != "created"
            or before["State"]["Running"] is not False
            or final["State"]["Status"] != "exited"
            or cleanup_receipt["removed"] is not True
        ):
            raise Refused("original execution cannot establish completed physical starts")
        return {
            "score": score,
            "runtime_digest": self.identity,
            "container_id": plan["container_id"],
            "nonce": plan["nonce"],
            "image_id": IMAGE,
            "runtime_source_digest": sha(self.runtime_bytes),
            "wrapper_source_digest": sha(self.wrapper_bytes),
            "worker_source_digest": sha(self.worker_bytes),
            "start_receipt_digest": start_digest,
            "stop_receipt_digest": stop_digest,
            "cleanup_receipt_digest": cleanup_digest,
            "container_starts": 1,
            "scoring_process_starts": 1,
            "lifecycle_seconds": result.get("lifecycle_seconds"),
        }


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--owner-fd", type=int, required=True)
    arguments = parser.parse_args()
    watchdog(arguments.plan, arguments.owner_fd)
