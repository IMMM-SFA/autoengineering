"""Confirmation access/score accounting for application-owned trusted scorers.

This module does not admit a private data path or provide process isolation.
Scorers receive only a selected-model reference and immutable grant identities.
Custodians must qualify their own scorer boundary before real confirmation use.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from autoengineering.campaign.artifacts import read_bytes, put_bytes, reference
from autoengineering.campaign.serialization import Record
from autoengineering.campaign.store import StoreError
from .contracts import ResourceCap, sha256
from .confirmation import read_manifest
from .outcomes import OutcomeSpec


@dataclass(frozen=True)
class ConfirmationGrant(Record):
    suite_digest: str
    cell_digest: str
    partition_digest: str
    scorer_digest: str
    outcome_digest: str
    model_digest: str
    selection_digest: str
    resources: tuple[ResourceCap, ...]

    def _validate(self):
        for value in (self.suite_digest, self.cell_digest, self.partition_digest, self.scorer_digest,
                      self.outcome_digest, self.model_digest, self.selection_digest):
            sha256(value)
        if not self.resources or len({r.name for r in self.resources}) != len(self.resources):
            raise ValueError("confirmation grant needs unique bounded resources")
        if not any(r.name == "scientific_starts" and r.units == "count" and r.limit == 1
                   and r.enforcement == "reservation" for r in self.resources):
            raise ValueError("confirmation requires one explicitly reserved scoring start")
        if any(r.limit > 0 and r.name in ("host_invocations", "training_starts") for r in self.resources):
            raise ValueError("confirmation cannot invoke agents or training")


@dataclass(frozen=True)
class PublicScore(Record):
    status: Literal["success", "scientific_infeasible", "model_failure", "timeout", "infrastructure_failure", "insufficient_data"]
    outcome: str
    units: str
    value: float | None
    feasible: bool | None

    def _validate(self):
        if self.status == "success" and (self.value is None or self.feasible is None):
            raise ValueError("successful confirmation needs finite outcome and feasibility")
        if self.status != "success" and self.value is not None:
            raise ValueError("failed confirmation cannot supply a penalty objective")


def _read(root, identity, name, kind):
    sha256(identity)
    ref = reference(root, f"artifacts/{identity}/{name}", media_type="application/json", producer="reader")
    if ref.sha256 != identity:
        raise StoreError("confirmation artifact identity changed")
    return kind.from_json(read_bytes(root, ref).decode())


def validate_grant(store, grant, frozen):
    if grant.suite_digest != store.spec.digest or grant.selection_digest != frozen:
        raise StoreError("confirmation grant is stale")
    cell = next((c for c in store.spec.cells if c.digest == grant.cell_digest), None)
    if cell is None:
        raise StoreError("confirmation cell is absent")
    task = next(t for t in store.spec.tasks if t.task_id == cell.task_id)
    if (grant.partition_digest, grant.outcome_digest) != (task.partition_digest, task.outcome_digest):
        raise StoreError("confirmation data/outcome identity differs")
    selected = next(c for c in read_manifest(store.root, frozen).cells if c.cell_digest == cell.digest)
    if selected.status != "selected" or selected.model.sha256 != grant.model_digest:
        raise StoreError("confirmation model is not the sealed selection")
    read_bytes(store.root, selected.model)
    return selected


def validate_access(store, event, frozen, allocation):
    grant = _read(store.root, event.result_digest, "confirmation-grant.json", ConfirmationGrant)
    validate_grant(store, grant, frozen)
    if grant.resources != allocation.resources:
        raise StoreError("confirmation access resources differ from charged reservation")
    if grant.cell_digest != event.cell_digest or grant.digest != event.child_digest:
        raise StoreError("access intent differs from reserved confirmation grant")


@dataclass(frozen=True)
class ConfirmationReceipt(Record):
    grant_digest: str
    access_digest: str
    score: PublicScore
    outcome_contract: OutcomeSpec

    def _validate(self):
        sha256(self.grant_digest)
        sha256(self.access_digest)
        if (self.score.outcome, self.score.units) != (self.outcome_contract.name, self.outcome_contract.units):
            raise ValueError("public score semantics differ from registered outcome")


def validate_score(store, event, access, frozen):
    receipt = _read(store.root, event.result_digest, "confirmation-score.json", ConfirmationReceipt)
    grant = _read(store.root, access, "confirmation-grant.json", ConfirmationGrant)
    validate_grant(store, grant, frozen)
    if receipt.outcome_contract.digest != grant.outcome_digest:
        raise StoreError("public outcome differs from frozen task")
    if (receipt.grant_digest, receipt.access_digest) != (grant.digest, access):
        raise StoreError("confirmation score differs from access intent")


class ConfirmationService:
    """One attempt per selected cell, with explicit application-owned scorer pins."""
    def __init__(self, store, scorer, *, scorer_digest, outcome_contract: OutcomeSpec):
        sha256(scorer_digest)
        self.store, self.scorer, self.scorer_digest = store, scorer, scorer_digest
        self.outcome_contract = outcome_contract

    def confirm(self, grant: ConfirmationGrant):
        with self.store.writer():
            state = self.store.replay()
            selected = validate_grant(self.store, grant, state["frozen"])
            if self.outcome_contract.digest != grant.outcome_digest:
                raise StoreError("confirmation outcome registration differs from task")
            if grant.scorer_digest != self.scorer_digest:
                raise StoreError("unregistered confirmation scorer identity")
            attempt = "confirmation-" + grant.cell_digest[:48]
            allocation = state["attempts"].get(attempt)
            if allocation is not None:
                if attempt in state["confirmation_scores"]:
                    return self._acknowledge(grant, attempt, state["confirmation_scores"][attempt])
                raise StoreError("confirmation attempt is uncertain; automatic retry refused")
            arguments = {"cell_digest": grant.cell_digest, "attempt_id": attempt,
                         "child_digest": grant.digest, "phase": "confirmation"}
            self.store.append(request_id=attempt+"-reserve", operation="reserve",
                              resources=grant.resources, **arguments)
            self.store.append(request_id=attempt+"-start", operation="start", **arguments)
            access = put_bytes(self.store.root, grant.to_json().encode(), name="confirmation-grant.json",
                               media_type="application/json", producer="trusted-confirmation")
            self.store.append(request_id=attempt+"-access", operation="confirmation_access",
                              result_digest=access.sha256, **arguments)
            self.store.fault("confirmation_access_committed")
            try:
                score = self.scorer(grant, selected.model)
                if not isinstance(score, PublicScore):
                    raise ValueError("invalid public score")
            except Exception:
                raise StoreError("confirmation scoring uncertain; access and charges retained") from None
            receipt = ConfirmationReceipt(grant.digest, access.sha256, score, self.outcome_contract)
            ref = put_bytes(self.store.root, receipt.to_json().encode(), name="confirmation-score.json",
                            media_type="application/json", producer="trusted-confirmation")
            self.store.fault("confirmation_score_created")
            self.store.append(request_id=attempt+"-score", operation="confirmation_score",
                              result_digest=ref.sha256, **arguments)
            self.store.fault("confirmation_score_committed")
            return self._acknowledge(grant, attempt, ref.sha256)

    def _acknowledge(self, grant, attempt, identity):
        receipt = _read(self.store.root, identity, "confirmation-score.json", ConfirmationReceipt)
        if receipt.grant_digest != grant.digest:
            raise StoreError("cannot resume confirmation under a changed grant")
        self.store.append(request_id=attempt+"-finish", operation="finish",
                          cell_digest=grant.cell_digest, attempt_id=attempt, child_digest=grant.digest,
                          phase="confirmation", result_digest=identity)
        return receipt


def read_receipt(root, identity):
    """Read a hash-verified public confirmation receipt without invoking its scorer."""
    return _read(root, identity, "confirmation-score.json", ConfirmationReceipt)
