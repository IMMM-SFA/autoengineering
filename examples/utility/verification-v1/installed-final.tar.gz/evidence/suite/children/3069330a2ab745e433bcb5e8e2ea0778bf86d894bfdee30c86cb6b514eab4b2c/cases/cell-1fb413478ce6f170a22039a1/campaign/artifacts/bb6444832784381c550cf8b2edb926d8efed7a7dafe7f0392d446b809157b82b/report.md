# Campaign agent-contract-fixture

Synthetic scalar orchestration fixture

Scientific specification: `15fd57b4a7e572ab5aa34348cff94aeeb073dbd00ef50380ddd19363c3536771`

Outcome: `accepted_candidate`.
Confirmation: `confirmation_not_attempted`.

Physical attempts: 2. Confirmed: 2. Unresolved: 0.
Reserved or consumed capacity: 2/2.
Measured cost: 2. Cost uncertainty: False.
Charged active time: 2.4698 seconds.

## Evaluations

| Evaluation | Split | Execution | RMSE | Checks |
| --- | --- | --- | --- | --- |
| evaluation-attempt-000001-comparison | comparison | success | 1.0 | finite: pass |
| evaluation-attempt-000002-comparison | comparison | success | 0.0 | finite: pass |

## Decisions

- Comparator `evaluation-attempt-000001-comparison`: `accepted_candidate`. Selection: `evaluation-attempt-000002-comparison`.
  - Applied frozen eligibility and ranking rules
- Comparator `evaluation-attempt-000001-comparison`: `accepted_candidate`. Selection: `evaluation-attempt-000002-comparison`.
  - Applied frozen eligibility and ranking rules

## Admission

- `response-linear-v2`: admitted.

[Immutable evaluation and check records](../../artifacts/85d91a163e7404cb088070a808d5cbdcbd35e665a9405015a6fac73faea9d22a/state.json).


## Immutable output evidence

- [evaluation-attempt-000001-comparison: output](../../artifacts/880293e562978f9bf21af6a684b55cf7e78c28aea2149d790bdb338c21bd74c8/outputs.npz), SHA-256 `880293e562978f9bf21af6a684b55cf7e78c28aea2149d790bdb338c21bd74c8`.
- [evaluation-attempt-000002-comparison: output](../../artifacts/c10da64ff241a5ec33d59fdd984dcd231f7e17a1ff00a32f56a0e7e3d40a3bcc/outputs.npz), SHA-256 `c10da64ff241a5ec33d59fdd984dcd231f7e17a1ff00a32f56a0e7e3d40a3bcc`.

## Limits

This experimental local workflow evaluates supplied trusted implementations. Process separation provides lifecycle control and is not a security sandbox. Token ceilings, production agent roles, new host integrations, automatic model training, and general scientific improvement remain deferred.

Exposed development data do not establish independent confirmation. Unknown costs and unavailable checks remain explicit. This report requires no private observation reads or network access.
